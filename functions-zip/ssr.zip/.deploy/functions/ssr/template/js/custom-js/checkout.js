// Add your custom JavaScript for checkout here.
window.ECOM_CONFIG = {
  default_img_size: 'big'
}
